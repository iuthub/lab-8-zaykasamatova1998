@extends('layouts.master')
@section('content')
<div class="row">
    <div class="col-md-12 text-center">
        <p class="quote">About Me</p>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Exercitationem repudiandae, suscipit, eligendi minus totam
            odit fuga eos cupiditate nisi, placeat repellendus adipisci nobis incidunt. Odio quos rem obcaecati tenetur?
            Hic laboriosam culpa distinctio, dicta facere voluptate error vitae consequatur! Quo ad numquam quasi vero commodi?
            Dolore architecto sed beatae ullam!
        </p>
    </div>
</div>
@endsection
